from typing import Literal
from langchain_core.messages import HumanMessage, SystemMessage, RemoveMessage
from langgraph.graph import MessagesState
from langgraph.graph import StateGraph, START, END

# 使用 GPT-4 模型进行对话和摘要生成
from langchain_openai import ChatOpenAI
model = ChatOpenAI(model="gpt-4o", temperature=0) 

# 定义状态类，用于存储消息和历史摘要
class State(MessagesState):
    summary: str
    
# 定义调用模型的逻辑
def call_model(state: State):
    
    # 获取已有的摘要（如果存在）
    summary = state.get("summary", "")

    # 如果有摘要，将其添加到消息中
    if summary:
        
        # 将摘要作为系统消息添加
        system_message = f"之前对话的摘要：{summary}"

        # 将摘要添加到所有新消息前面
        messages = [SystemMessage(content=system_message)] + state["messages"]
    
    else:
        messages = state["messages"]
    
    response = model.invoke(messages)
    return {"messages": response}

# 决定是结束对话还是执行摘要
def should_continue(state: State) -> Literal["summarize_conversation", "__end__"]:
    
    """返回下一个要执行的节点"""
    
    messages = state["messages"]
    
    # 当消息数量超过 10 条时，执行对话摘要
    if len(messages) > 10:
        return "summarize_conversation"
    
    # 否则正常结束
    return END

def summarize_conversation(state: State):
    
    # 首先获取已有摘要（如果存在）
    summary = state.get("summary", "")

    # 创建摘要提示词
    if summary:
        
        # 如果已有摘要，则扩展现有摘要
        summary_message = (
            f"这是到目前为止的对话摘要：{summary}\n\n"
            "请根据上面的新消息扩展这个摘要："
        )
        
    else:
        # 如果没有摘要，创建新的摘要
        summary_message = "请为上面的对话创建一个摘要："

    # 将提示词添加到历史消息中
    messages = state["messages"] + [HumanMessage(content=summary_message)]
    response = model.invoke(messages)
    
    # 删除除最后 3 条消息外的所有消息，并更新摘要到状态中
    delete_messages = [RemoveMessage(id=m.id) for m in state["messages"][:-3]]
    return {"summary": response.content, "messages": delete_messages}

# 定义一个新的图结构
workflow = StateGraph(State)
workflow.add_node("conversation", call_model)
workflow.add_node(summarize_conversation)

# 设置入口点为对话节点
workflow.add_edge(START, "conversation")
workflow.add_conditional_edges("conversation", should_continue)
workflow.add_edge("summarize_conversation", END)

# 编译图
graph = workflow.compile()